package com.annajubs.etimpamannajliaprojetosqlite;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DAO extends SQLiteOpenHelper {
    private static final String TAG = "AppDataBase";
    public static final String DB_NAME = "app.sqlite";
    public static int version = 1;

    public DAO(Context context) {
        super(context, DB_NAME, null, version);
        // NÃO chamar getWritableDatabase() aqui; deixe o Android controlar (evita double init)
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }
}

