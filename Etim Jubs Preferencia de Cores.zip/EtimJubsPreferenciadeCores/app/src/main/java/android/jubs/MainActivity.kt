package android.jubs

import android.graphics.Color
import android.jubs.databinding.ActivityMainBinding
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.google.android.material.snackbar.Snackbar

class MainActivity : AppCompatActivity() {
    lateinit var binding : ActivityMainBinding
    private var cor = ""

    companion object{
        const val NOME_ARQUIVO = "arquivo_prefs.xml"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        //supportActionBar!!.hide()
        window.statusBarColor = Color.WHITE
        binding = ActivityMainBinding.inflate(layoutInflater)

        setContentView(binding.root)

        binding.btnCor1.setOnClickListener{
            cor = "#01161E"
            binding.LayoutPrincipal.setBackgroundColor(Color.parseColor(cor))
        }

        binding.btnCor2.setOnClickListener{
            cor = "#124559"
            binding.LayoutPrincipal.setBackgroundColor(Color.parseColor(cor))

        }

        binding.btnCor3.setOnClickListener{
            cor = "#598392"
            binding.LayoutPrincipal.setBackgroundColor(Color.parseColor(cor))

        }

        binding.btnCor4.setOnClickListener{
            cor = "#AEC3B0"
            binding.LayoutPrincipal.setBackgroundColor(Color.parseColor(cor))

        }

        binding.btnCor5.setOnClickListener{
            cor = "#EFF6E0"
            binding.LayoutPrincipal.setBackgroundColor(Color.parseColor(cor))

        }

        binding.btnTrocar.setOnClickListener {view ->
            binding.LayoutPrincipal.setBackgroundColor(Color.parseColor(cor))

            val preferencias = getSharedPreferences(NOME_ARQUIVO, MODE_PRIVATE)
            val editor = preferencias.edit()
            editor.putString("cor", cor)
            editor.putString("nome", "Anna Júlia")
            editor.putString("sobrenome", "Prado")
            editor.putString("idade", "17")
            editor.apply()

            snackBar(view)
        }

    }

    override fun onResume() {
        super.onResume()

        val preferencias = getSharedPreferences(NOME_ARQUIVO, MODE_PRIVATE)
        val cor = preferencias.getString("cor", cor)

        if (cor!!.isNotEmpty()) {
            binding.LayoutPrincipal.setBackgroundColor(Color.parseColor(cor))
        }
    }



    private fun snackBar(view: View) {
        val snackbar = Snackbar.make(view, "cor de fundo alterada com sucesso!", Snackbar.LENGTH_INDEFINITE)
        snackbar.setAction("OK"){

        }

        snackbar.setActionTextColor(Color.BLUE)
        snackbar.setBackgroundTint(Color.LTGRAY)
        snackbar.setTextColor(Color.GREEN)
        snackbar.show()
    }
}
