package com.example.fragmentscomkotlinjubs

import android.app.Activity
import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import android.widget.TableLayout

import com.example.fragmentscomkotlinjubs.databinding.ActivityMainBinding
import com.google.android.material.tabs.TabLayout

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding


    val tableLayout : TableLayout = findViewById(R.id.table_layout)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        val view = binding.root
        setContentView(view)

        binding.tableLayout.addOnTabSelectedListener(
            object:TabLayout.OnTabSelectedListener{
                override fun onTabSelected(tab: TabLayout.Tab?) {
                    when(tab?.position){
                        0-> supportFragmentManager
                            .beginTransaction()
                            .replace(R.id.fragmentContainerView, PrimeiroFragmento())
                            .commit()
                        1-> supportFragmentManager
                            .beginTransaction()
                            .replace(R.id.fragmentContainerView, SegundoFragmento())
                            .commit()
                        2-> supportFragmentManager
                            .beginTransaction()
                            .replace(R.id.fragmentContainerView, TerceiroFragmento())
                            .commit()
                    }
                }

                override fun onTabUnselected(tab: TabLayout.Tab?) {

                }

                override fun onTabReselected(tab: TabLayout.Tab?) {

                }

            }
        )


    }
}