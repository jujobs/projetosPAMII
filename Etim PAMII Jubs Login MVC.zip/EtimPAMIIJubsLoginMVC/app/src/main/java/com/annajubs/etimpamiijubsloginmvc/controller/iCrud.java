package com.annajubs.etimpamiijubsloginmvc.controller;

import java.util.List;
public interface iCrud <T>{
    public boolean inserir(T t);

    public boolean alterar(T t);

    public boolean deletar(T t);
    public T buscar(int id);

    public List<T> listar();

}
