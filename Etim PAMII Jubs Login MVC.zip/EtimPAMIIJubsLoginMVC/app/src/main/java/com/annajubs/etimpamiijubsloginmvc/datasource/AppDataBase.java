package com.annajubs.etimpamiijubsloginmvc.datasource;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import com.annajubs.etimpamiijubsloginmvc.datamodel.UsuarioDataModel;
import com.annajubs.etimpamiijubsloginmvc.model.Usuario;

import java.security.spec.ECField;

public class AppDataBase extends SQLiteOpenHelper {
    SQLiteDatabase sqLiteDatabase;
    public  static final String NAME = "app.sqlite";
    public static int version = 1;
    public AppDataBase( Context context ) {
        super(context, NAME, null, version);
        sqLiteDatabase = getWritableDatabase();
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        sqLiteDatabase.execSQL(UsuarioDataModel.criarTabela());
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }

    public boolean insert(String tabela, ContentValues dados) {
        sqLiteDatabase = getWritableDatabase();
        boolean retorno = false;

        try {
            retorno = sqLiteDatabase.insert(tabela, null, dados) > 0;
        } catch (Exception e) {
            e.getMessage();
        }

        return retorno;

    }

    public boolean CheckUserPass(String email, String senha) {
        sqLiteDatabase=getWritableDatabase();

        Cursor cursor = sqLiteDatabase.rawQuery("SELECT * FROM usuario WHERE email = ? AND senha = ?"
        new String[]{email, senha})
        return cursor.getCount() > 0;
    }

    public Boolean checkUserPassword(String username, String password){
        sqLiteDatabase = getWritableDatabase();
        boolean retorno = false;
        Cursor cursor = sqLiteDatabase.rawQuery("SELECT * FROM " + UsuarioDataModel.TABELA + " WHERE username = ?"
                       " AND password = ?",
                new String[]{username, password});
        return cursor.getCount() > 0;
    }

    public Boolean checkUser(String email) {
        sqLiteDatabase = getWritableDatabase();
        Cursor cursor = sqLiteDatabase.rawQuery("SELECT * FROM  usuario WHERE email = ?" +
                new String[]{email});
        return cursor.getCount() > 0;
    }
}
