package com.annajubs.etimpamiijubsloginmvc.view;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.annajubs.etimpamiijubsloginmvc.R;
import com.annajubs.etimpamiijubsloginmvc.controller.UsuarioController;
import com.annajubs.etimpamiijubsloginmvc.model.Usuario;

public class MainActivity extends AppCompatActivity {

    private EditText email, senha;
    private Button entrar, criar;
    Usuario usuario;
    UsuarioController controller;


    @Override
    protected void onCreate(Bundle savedInstanceState) {

        entrar.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if (validaCampos()) {
                    //instancio um usuario e um usuarioController
                    usuario = new Usuario();
                    controller = new UsuarioController(getApplicationContext());

                    //pego o que o usuario digitou e passo para bariabeis locais
                    String user = usuario.getEmail().toString();
                    String pass = usuario.getSenha().toString();

                    //passo das variaveis locais para o objeto usuario
                    usuario.setEmail(user);
                    usuario.setSenha(pass);

                    //verifico se o usuario e senha existem na tabela
                    boolean isCheckUser = controller.usuarioeSenha(user, pass);

                    //se nao existir uma mensagem de usuario nao cadastrado
                    if (!isCheckUser){
                    Toast.makeText(MainActivity.this, "Usuario ainda não cadastrado", Toast);
                    }else{
                        //caso contrario mando ele para a pagina principal homeactivity
                        Intent home = new Intent(MainActivity.this, HomeActivity.class);
                        startActivity(home);
                    }
                }
            }
        });


        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    private void initComponents() {
        email = findViewById(R.id.cad_edt_email);
        senha = findViewById(R.id.cad_edt_senha);
        entrar = findViewById(R.id.sign_in);
        criar = findViewById(R.id.sign_up);

    }

    private boolean validaCampos() {
        boolean camposValidados = true;
        if (email.getText().toString().equals("")){
            camposValidados = false;
            email.setError("Digite o email");
            email.requestFocus();
        }
        if (senha.getText().toString().equals("")) {
            camposValidados = false;
            senha.setError("Digite sua senha");
            senha.requestFocus();
        }
        return camposValidados;
    }
}