package com.annajubs.etimpamiijubsloginmvc.datamodel;

public class UsuarioDataModel {

    //TODA classe DataModel tem essa estrutura aki:
    // 1 - atributo nome da tabela
    // 2 - atributos um para um com os nomes dos campos
    // 3 - query para criar a tabela no banco de dados
    // 4 - metodo para gerar o script para criar a tabela

    //1
    public static final String TABELA = "usuario";

    //2
    public static final String ID = "id";

    public static final String NOME = "nome";

    public static final String EMAIL = "email";

    public static final String SENHA = "senha";

    public static String criarTabela() {
        return "CREATE TABLE " + TABELA + " (" +
                ID      + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                NOME    + " TEXT, " +
                EMAIL   + " TEXT, " +
                SENHA   + " TEXT)";
    }
}
